﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumberToWordConverter
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter a number: ");
            string input = Console.ReadLine();
            long inputNumber;
            if (long.TryParse(input, out inputNumber) && inputNumber >= 0 && inputNumber <= 999999999)
            {
                Console.WriteLine(ConvertToWords(inputNumber));
            }
            else
            {
                Console.WriteLine("Invalid number");
            }
            Console.ReadKey();
        }

        public static string ConvertToWords(long number)
        {
            if (number == 0) return "zero";
            string words = string.Empty;
            if ((number / 1000000) > 0)
            {
                words += ConvertToWords(number / 1000000) + " million ";
                number %= 1000000;
            }
            if ((number / 1000) > 0)
            {
                words += ConvertToWords(number / 1000) + " thousand and ";
                number %= 1000;
            }
            if ((number / 100) > 0)
            {
                words += ConvertToWords(number / 100) + " hundred and ";
                number %= 100;
            }
            if (number > 0)
            {
                var unitsArray = new[]
                {
                    "zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen", "nineteen"
                };
                var tensArray = new[]
                {
                    "zero", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety"
                };
                if (number < 20)
                {
                    words += unitsArray[number];
                }
                else
                {
                    words += tensArray[number / 10];
                    if ((number % 10) > 0)
                    {
                        words += " " + unitsArray[number % 10];
                    }
                }
            }
            return words;
        }
    }
}

